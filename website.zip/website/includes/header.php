<!-- header.php -->
<!DOCTYPE html>
<html lang="en">

<head>
    <title>My PHP Website</title>
    <link rel="stylesheet" href="styles/styles.css">
</head>

<body>
    <header>
        <div class ="thead">
            <div class="lhead">
                <h1 class="h1">Visitor Management</h1>
            </div>
            <div class = "rhead">
                <nav>
                    <ul>
                        <a style="margin-left: 20px;" href="http://localhost/website/index.php">Home</a>
                        <a style="margin-left: 20px;" href="http://localhost/website/about.php">About</a>
                        <a style="margin-left: 20px;" href="http://localhost/website/contact.php">Contact</a>
                    </ul>
                </nav>
            </div>
        </div>

    </header>