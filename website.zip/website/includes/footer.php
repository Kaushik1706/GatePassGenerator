<!-- footer.php -->
<footer>
    <link rel="stylesheet" href="styles/styles.css">
        <p class="footer">&copy; 2024 PHP Website</p>
    </footer>
</body>
</html>
